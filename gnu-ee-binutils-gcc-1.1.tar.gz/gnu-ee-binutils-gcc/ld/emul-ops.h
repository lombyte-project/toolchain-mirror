#define DEFAULT_EMULATION "elf32l5900" 
#define SCRIPTDIR "/usr/local/sce/ee/gcc/ee/lib" 
#define TARGET "mips64r5900-sky-elf"
